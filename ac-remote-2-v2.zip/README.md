# AC Remote 2 (LG AKB76044902 test build)
Comfort Air tile = test button: each tap sends the next known vertical-swing frame.

# LG AC Remote (AKB75415302 layout), version 2

Vivo போன்ல இருக்கிற IR blaster மூலமா LG AC-ஐ இயக்கும் Android app.

## வேலை செய்யுற பட்டன்கள்

Power, Mode, Temp up/down, Fan Speed, Energy Ctrl (80/60/40%), H'Cool (Jet),
Swing vertical, Swing horizontal, Light Off/On, Sleep (1-7 மணி), Timer (ON/OFF),
Set/Cancel, Func (Auto Clean, Plasma).

வேலை செய்யாதவை: Comfort Air (IR code கிடைக்கல), Room Temp (AC-ல இருந்து படிக்க முடியாது).

## AC response பண்ணலன்னா

App-ஓட கீழ "Setup" பட்டனை தொடுங்க. 5 option இருக்கு. "Test அனுப்பு" அழுத்தி AC beep பண்ணுதான்னு பாருங்க.
Beep வரலன்னா ஒரு option-ஐ மாத்தி மறுபடி Test பண்ணுங்க.
