package com.example.lgacremote;

import android.content.Context;
import android.graphics.BlurMaskFilter;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.Path;
import android.view.MotionEvent;
import android.view.View;

/**
 * Airflow illustration. Vertical: 6 rays fanning down-left, one per vane position.
 * Horizontal: 7 rays fanning down. The active ray glows; while swinging the glow sweeps.
 */
public class AirflowView extends View {

    private final boolean vertical;
    private final float density;
    private final Paint outline = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint rayOn = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint rayGlow = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint rayOff = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint dotOn = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint dotOff = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Path path = new Path();

    private int pos = 3;
    private boolean swinging = false;

    /** Called when the user taps/drags onto a ray (vertical view only). */
    public interface OnRayListener { void onRay(int index); }
    private OnRayListener rayListener;
    private float shown = -1f;      // animated (eased) ray position
    private int touchIdx = -1;      // ray under the finger while touching
    private float pvX, pvY, pvR0, pvR1;  // fan geometry, kept for hit-testing

    public void setOnRayListener(OnRayListener l) { rayListener = l; }

    public AirflowView(Context c, boolean vertical) {
        super(c);
        this.vertical = vertical;
        density = getResources().getDisplayMetrics().density;
        setLayerType(LAYER_TYPE_SOFTWARE, null);

        outline.setStyle(Paint.Style.STROKE);
        outline.setStrokeCap(Paint.Cap.ROUND);
        outline.setStrokeJoin(Paint.Join.ROUND);
        outline.setStrokeWidth(5 * density);
        outline.setColor(0xFF8A94A6);

        rayOn.setStyle(Paint.Style.STROKE);
        rayOn.setStrokeCap(Paint.Cap.ROUND);
        rayOn.setStrokeWidth(6 * density);
        rayOn.setColor(0xFF5B8CFF);

        rayGlow.setStyle(Paint.Style.STROKE);
        rayGlow.setStrokeCap(Paint.Cap.ROUND);
        rayGlow.setStrokeWidth(10 * density);
        rayGlow.setColor(0xAA3FD0FF);
        rayGlow.setMaskFilter(new BlurMaskFilter(7 * density, BlurMaskFilter.Blur.NORMAL));

        rayOff.setStyle(Paint.Style.STROKE);
        rayOff.setStrokeCap(Paint.Cap.ROUND);
        rayOff.setStrokeWidth(5 * density);
        rayOff.setColor(0x555B8CFF);

        dotOn.setStyle(Paint.Style.FILL);
        dotOn.setColor(0xFF7FB0FF);
        dotOff.setStyle(Paint.Style.FILL);
        dotOff.setColor(0x445B8CFF);
    }

    /** pos: 0..5 for vertical (Highest..Lowest). swinging: sweep through all rays. */
    public void setState(int pos, boolean swinging) {
        this.pos = pos;
        this.swinging = swinging;
        invalidate();
    }

    /** Index of the ray nearest to the touch point, or -1 if outside the fan. */
    private int rayAt(float x, float y) {
        float dx = x - pvX, dy = y - pvY;
        double dist = Math.hypot(dx, dy);
        if (dist < pvR0 * 0.4 || dist > pvR1 * 1.35) return -1;
        double deg = Math.toDegrees(Math.atan2(dy, dx));
        if (deg < 0) deg += 360;
        double a0 = 172, a1 = 100;
        int n = 6;
        double step = (a0 - a1) / (n - 1);
        if (deg > a0 + step * 0.9 || deg < a1 - step * 0.9) return -1;
        int idx = (int) Math.round((a0 - deg) / step);
        return Math.max(0, Math.min(n - 1, idx));
    }

    @Override
    public boolean onTouchEvent(MotionEvent e) {
        if (!vertical || rayListener == null) return super.onTouchEvent(e);
        switch (e.getActionMasked()) {
            case MotionEvent.ACTION_DOWN:
                if (rayAt(e.getX(), e.getY()) < 0) return false;
                getParent().requestDisallowInterceptTouchEvent(true);
                // fall through
            case MotionEvent.ACTION_MOVE: {
                int i = rayAt(e.getX(), e.getY());
                if (i >= 0) touchIdx = i;
                invalidate();
                return true;
            }
            case MotionEvent.ACTION_UP: {
                int i = rayAt(e.getX(), e.getY());
                if (i < 0) i = touchIdx;
                touchIdx = -1;
                if (i >= 0) {
                    performClick();
                    rayListener.onRay(i);
                }
                invalidate();
                return true;
            }
            case MotionEvent.ACTION_CANCEL:
                touchIdx = -1;
                invalidate();
                return true;
        }
        return true;
    }

    @Override
    public boolean performClick() { return super.performClick(); }

    @Override
    protected void onMeasure(int widthSpec, int heightSpec) {
        setMeasuredDimension((int) (170 * density), (int) (130 * density));
    }

    @Override
    protected void onDraw(Canvas canvas) {
        super.onDraw(canvas);
        float w = getWidth();
        float h = getHeight();
        path.reset();

        float px, py, r0, r1;
        int n;
        double a0, a1;
        if (vertical) {
            path.moveTo(w * 0.04f, h * 0.06f);
            path.lineTo(w * 0.66f, h * 0.06f);
            path.quadTo(w * 0.74f, h * 0.06f, w * 0.74f, h * 0.16f);
            path.lineTo(w * 0.92f, h * 0.16f);
            path.lineTo(w * 0.92f, h * 0.94f);
            px = w * 0.80f;
            py = h * 0.22f;
            r0 = w * 0.16f;
            r1 = w * 0.62f;
            n = 6;
            a0 = 172;
            a1 = 100;
        } else {
            path.moveTo(w * 0.05f, h * 0.36f);
            path.lineTo(w * 0.36f, h * 0.08f);
            path.quadTo(w * 0.5f, h * 0.24f, w * 0.64f, h * 0.08f);
            path.lineTo(w * 0.95f, h * 0.36f);
            px = w * 0.5f;
            py = h * 0.24f;
            r0 = h * 0.26f;
            r1 = h * 0.72f;
            n = 7;
            a0 = 142;
            a1 = 38;
        }
        canvas.drawPath(path, outline);
        pvX = px; pvY = py; pvR0 = r0; pvR1 = r1;

        int active;
        if (swinging) {
            long t = (System.currentTimeMillis() / 220) % (2 * (n - 1));
            active = (int) (t < n ? t : 2 * (n - 1) - t);
        } else {
            active = vertical ? (touchIdx >= 0 ? touchIdx : pos) : n / 2;
        }

        // ease the lit ray smoothly toward its target (fixed position only)
        boolean easing = false;
        float drawPos = active;
        if (!swinging && vertical) {
            if (shown < 0) shown = active;
            float diff = active - shown;
            if (Math.abs(diff) < 0.03f) shown = active;
            else { shown += diff * 0.28f; easing = true; }
            drawPos = shown;
        }

        for (int i = 0; i < n; i++) {
            if (i == active) continue;   // lit ray drawn last
            drawRay(canvas, px, py, r0, r1, a0, a1, n, i, false);
        }
        drawRay(canvas, px, py, r0, r1, a0, a1, n, (swinging || !vertical) ? active : drawPos, true);

        if (swinging || easing) postInvalidateOnAnimation();
    }

    private void drawRay(Canvas canvas, float px, float py, float r0, float r1,
                         double a0, double a1, int n, float idx, boolean lit) {
        double deg = a0 + (a1 - a0) * idx / (n - 1);
        double rad = Math.toRadians(deg);
        float cs = (float) Math.cos(rad);
        float sn = (float) Math.sin(rad);
        float sx = px + cs * r0;
        float sy = py + sn * r0;
        float ex = px + cs * r1;
        float ey = py + sn * r1;
        if (lit) {
            canvas.drawLine(sx, sy, ex, ey, rayGlow);
            canvas.drawLine(sx, sy, ex, ey, rayOn);
            canvas.drawCircle(ex + cs * 9 * density, ey + sn * 9 * density, 3.5f * density, dotOn);
        } else {
            canvas.drawLine(sx, sy, ex, ey, rayOff);
            canvas.drawCircle(ex + cs * 9 * density, ey + sn * 9 * density, 3f * density, dotOff);
        }
    }
}
