package com.example.lgacremote;

import android.animation.Animator;
import android.animation.AnimatorListenerAdapter;
import android.animation.ValueAnimator;
import android.graphics.Canvas;
import android.graphics.ColorFilter;
import android.graphics.Paint;
import android.graphics.Path;
import android.graphics.PixelFormat;
import android.graphics.RectF;
import android.graphics.drawable.Drawable;
import android.view.View;

import java.util.Random;
import java.util.WeakHashMap;

/** Short touch animations drawn over a view: snow, water drops, wind, sparkles, rays, waves. */
public final class Fx {
    public static final int COOL = 0, DRY = 1, WIND = 2, AUTO = 3, STARS = 4, RAYS = 5, WAVES = 6, PULSE = 7;

    private static final WeakHashMap<View, Active> RUNNING = new WeakHashMap<>();

    private static final class Active {
        Drawable d;
        ValueAnimator a;
    }

    private Fx() {
    }

    public static void play(View host, int type, int cornerDp) {
        if (host.getWidth() == 0 || host.getHeight() == 0) return;
        Active old = RUNNING.get(host);
        if (old != null) {
            old.a.cancel();
        }
        final float density = host.getResources().getDisplayMetrics().density;
        final FxDrawable d = new FxDrawable(type, density, cornerDp);
        d.setBounds(0, 0, host.getWidth(), host.getHeight());
        host.getOverlay().add(d);
        ValueAnimator a = ValueAnimator.ofFloat(0f, 1f);
        a.setDuration(type == COOL || type == DRY ? 1700 : 1300);
        a.addUpdateListener(an -> {
            d.t = (float) an.getAnimatedValue();
            d.invalidateSelf();
        });
        a.addListener(new AnimatorListenerAdapter() {
            @Override
            public void onAnimationEnd(Animator animation) {
                host.getOverlay().remove(d);
                Active cur = RUNNING.get(host);
                if (cur != null && cur.d == d) RUNNING.remove(host);
            }

            @Override
            public void onAnimationCancel(Animator animation) {
                host.getOverlay().remove(d);
            }
        });
        Active act = new Active();
        act.d = d;
        act.a = a;
        RUNNING.put(host, act);
        a.start();
    }

    private static final class FxDrawable extends Drawable {
        final int type;
        final float dn;
        final int corner;
        float t;
        final Paint p = new Paint(Paint.ANTI_ALIAS_FLAG);
        final Path path = new Path();
        final RectF rect = new RectF();
        static final int N = 16;
        final float[] x0 = new float[N], delay = new float[N], size = new float[N], ph = new float[N];

        FxDrawable(int type, float dn, int corner) {
            this.type = type;
            this.dn = dn;
            this.corner = corner;
            Random r = new Random(System.nanoTime());
            for (int i = 0; i < N; i++) {
                x0[i] = 0.06f + 0.88f * r.nextFloat();
                delay[i] = 0.45f * r.nextFloat();
                size[i] = 0.6f + 0.8f * r.nextFloat();
                ph[i] = r.nextFloat() * 6.28f;
            }
        }

        @Override
        public void draw(Canvas c) {
            Rect0 b = new Rect0(getBounds().width(), getBounds().height());
            float w = b.w, h = b.h;
            c.save();
            if (corner > 0) {
                rect.set(0, 0, w, h);
                path.reset();
                path.addRoundRect(rect, corner * dn, corner * dn, Path.Direction.CW);
                c.clipPath(path);
            }
            float fade = (float) Math.sin(Math.PI * Math.min(1f, t));
            p.setShader(null);
            switch (type) {
                case COOL:
                    p.setStyle(Paint.Style.FILL);
                    p.setColor(((int) (70 * fade) << 24) | 0x3FD0FF);
                    c.drawRect(0, 0, w, h, p);
                    for (int i = 0; i < N; i++) {
                        float q = clamp(t * 1.5f - delay[i]);
                        if (q <= 0f || q >= 1f) continue;
                        float x = x0[i] * w + (float) Math.sin(q * 6 + ph[i]) * 8 * dn;
                        float y = -10 * dn + q * (h + 20 * dn);
                        snow(c, x, y, 5.5f * dn * size[i], (int) (255 * Math.sin(Math.PI * q)));
                    }
                    break;
                case DRY:
                    p.setStyle(Paint.Style.FILL);
                    p.setColor(((int) (50 * fade) << 24) | 0x2F7BFF);
                    c.drawRect(0, 0, w, h, p);
                    for (int i = 0; i < N; i++) {
                        float q = clamp(t * 1.6f - delay[i]);
                        if (q <= 0f || q >= 1f) continue;
                        float x = x0[i] * w;
                        float fall = Math.min(1f, q / 0.8f);
                        float y = -8 * dn + fall * (h - 4 * dn);
                        if (q < 0.8f) {
                            drop(c, x, y, 4.5f * dn * size[i], 230);
                        } else {
                            float rq = (q - 0.8f) / 0.2f;
                            p.setStyle(Paint.Style.STROKE);
                            p.setStrokeWidth(1.6f * dn);
                            p.setColor(((int) (200 * (1 - rq)) << 24) | 0x7FC8FF);
                            rect.set(x - 12 * dn * rq, h - 5 * dn - 3 * dn * rq, x + 12 * dn * rq, h - 5 * dn + 3 * dn * rq);
                            c.drawOval(rect, p);
                        }
                    }
                    break;
                case WIND:
                    p.setStyle(Paint.Style.STROKE);
                    p.setStrokeCap(Paint.Cap.ROUND);
                    p.setStrokeWidth(2.2f * dn);
                    for (int i = 0; i < 6; i++) {
                        float q = clamp(t * 1.4f - i * 0.07f);
                        if (q <= 0f || q >= 1f) continue;
                        float y = h * (0.15f + 0.14f * i);
                        float len = w * 0.4f;
                        float x = -len + q * (w + len);
                        path.reset();
                        path.moveTo(x, y);
                        path.cubicTo(x + len * 0.3f, y - 8 * dn, x + len * 0.6f, y + 8 * dn, x + len, y);
                        p.setColor(((int) (230 * Math.sin(Math.PI * q)) << 24) | 0xBFF3FF);
                        c.drawPath(path, p);
                    }
                    break;
                case WAVES:
                    p.setStyle(Paint.Style.STROKE);
                    p.setStrokeCap(Paint.Cap.ROUND);
                    p.setStrokeWidth(2.4f * dn);
                    for (int k = 0; k < 3; k++) {
                        path.reset();
                        float base = h * (0.3f + 0.2f * k);
                        for (int s = 0; s <= 24; s++) {
                            float x = w * s / 24f;
                            float y = base + (float) Math.sin(s * 0.55f + t * 14f + k) * 6 * dn;
                            if (s == 0) path.moveTo(x, y);
                            else path.lineTo(x, y);
                        }
                        p.setColor(((int) (230 * fade) << 24) | 0x3FD0FF);
                        c.drawPath(path, p);
                    }
                    break;
                case RAYS:
                    p.setStyle(Paint.Style.STROKE);
                    p.setStrokeCap(Paint.Cap.ROUND);
                    p.setStrokeWidth(2.4f * dn);
                    p.setColor(((int) (240 * fade) << 24) | 0xFFE08A);
                    for (int i = 0; i < 12; i++) {
                        double a = Math.PI * 2 * i / 12;
                        float r0 = Math.min(w, h) * 0.18f + t * 8 * dn;
                        float r1 = r0 + Math.min(w, h) * 0.30f * Math.min(1f, t * 2f);
                        c.drawLine(w / 2 + (float) Math.cos(a) * r0, h / 2 + (float) Math.sin(a) * r0,
                                w / 2 + (float) Math.cos(a) * r1, h / 2 + (float) Math.sin(a) * r1, p);
                    }
                    break;
                case PULSE:
                    p.setStyle(Paint.Style.STROKE);
                    p.setStrokeWidth(3 * dn);
                    p.setColor(((int) (200 * (1 - t)) << 24) | 0x3FD0FF);
                    float rr = Math.max(w, h) * 0.6f * t;
                    c.drawCircle(w / 2, h / 2, rr, p);
                    break;
                default: // AUTO and STARS: twinkling four-point sparkles
                    p.setStyle(Paint.Style.FILL);
                    for (int i = 0; i < N; i++) {
                        float q = clamp(t * 1.5f - delay[i]);
                        if (q <= 0f || q >= 1f) continue;
                        float s = (float) Math.sin(Math.PI * q);
                        int col = type == STARS ? 0xFFF1B8 : (i % 2 == 0 ? 0x3FD0FF : 0xC48BFF);
                        p.setColor(((int) (255 * s) << 24) | col);
                        sparkle(c, x0[i] * w, (0.15f + 0.7f * ((i * 37) % 100) / 100f) * h, 7 * dn * size[i] * s);
                    }
                    break;
            }
            c.restore();
        }

        private float clamp(float v) {
            return v < 0f ? 0f : Math.min(v, 1f);
        }

        private void snow(Canvas c, float x, float y, float r, int alpha) {
            p.setStyle(Paint.Style.STROKE);
            p.setStrokeCap(Paint.Cap.ROUND);
            p.setStrokeWidth(1.6f * dn);
            p.setColor((alpha << 24) | 0xD8F8FF);
            for (int k = 0; k < 3; k++) {
                double a = Math.PI * k / 3 + t * 2;
                float dx = (float) Math.cos(a) * r;
                float dy = (float) Math.sin(a) * r;
                c.drawLine(x - dx, y - dy, x + dx, y + dy, p);
            }
        }

        private void drop(Canvas c, float x, float y, float r, int alpha) {
            p.setStyle(Paint.Style.FILL);
            p.setColor((alpha << 24) | 0x59B8FF);
            path.reset();
            path.moveTo(x, y - r * 2.2f);
            path.quadTo(x + r * 1.3f, y - r * 0.4f, x + r, y + r * 0.2f);
            path.quadTo(x, y + r * 1.4f, x - r, y + r * 0.2f);
            path.quadTo(x - r * 1.3f, y - r * 0.4f, x, y - r * 2.2f);
            c.drawPath(path, p);
        }

        private void sparkle(Canvas c, float x, float y, float r) {
            path.reset();
            path.moveTo(x, y - r);
            path.quadTo(x, y, x + r, y);
            path.quadTo(x, y, x, y + r);
            path.quadTo(x, y, x - r, y);
            path.quadTo(x, y, x, y - r);
            c.drawPath(path, p);
        }

        @Override
        public void setAlpha(int alpha) {
        }

        @Override
        public void setColorFilter(ColorFilter cf) {
        }

        @Override
        public int getOpacity() {
            return PixelFormat.TRANSLUCENT;
        }
    }

    private static final class Rect0 {
        final int w, h;

        Rect0(int w, int h) {
            this.w = w;
            this.h = h;
        }
    }
}
